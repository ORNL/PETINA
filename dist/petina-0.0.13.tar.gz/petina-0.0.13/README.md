# PETINA: Privacy prEservaTIoN Algorithms
To install please use the instractions on this page: https://test.pypi.org/project/petina/0.0.11/. If you use any of the code please use the appropriate citation from here https://www.osti.gov/doecode/biblio/149859.

## Acknowledgement
This manuscript has been co-authored by UT-Battelle, LLC, under Contract No. DE-AC05-00OR22725 with the U.S. Department of Energy. The United States Government retains and the publisher, by accepting the article for publication, acknowledges that the United States Government retains a nonexclusive, paid-up, irrevocable, world-wide license to publish or reproduce the published form of this manuscript, or allow others to do so, for United States Government purposes. The Department of Energy will provide public access to these results of federally sponsored research in accordance with the DOE Public Access Plan (http://energy.gov/downloads/doe-public-access-plan).
